package edu.buffalo.cse.irf14.query;

public class QueryParserException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2659971991960601788L;
	
	protected QueryParserException(String message) {
		super(message);
	}

}
