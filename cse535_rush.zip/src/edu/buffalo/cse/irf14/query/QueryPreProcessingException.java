package edu.buffalo.cse.irf14.query;

public class QueryPreProcessingException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6000455285542788160L;

	/**
	 * 
	 */

	protected QueryPreProcessingException(String message) {
		super(message);
	}

}
