package edu.buffalo.cse.irf14.scoring;

public class ScorerException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2659971991960601788L;
	
	public ScorerException(String message) {
		super(message);
	}

}
